/**
 * 遅刻申請フォーム生成
 *
 * @param {string} key 申請キー
 * @param {Object} node フォームの親ノード
 * @param {string} contId IDに使用する番号
 * @param {Object=} applyObj 申請データ
 */
teasp.dialog.EmpApply.prototype.createLateStartForm = function(key, node, contId, applyObj, btnbox){
	var fix = (applyObj && teasp.constant.STATUS_FIX.contains(applyObj.status) || this.isReadOnly());
	var inputClass = this.getInputClass(fix, applyObj);

	var tbody = dojo.create('div', null, node);

	// 出社時刻
	var row = dojo.create('div', { id: 'dialogApplyTimeRow' + contId, className:'empApply2Div' }, tbody);
	dojo.create('div', { className: 'empApply2CL', innerHTML: teasp.message.getLabel('startTime_label') }, row); // 出社時刻
	var inp = dojo.create('input', { type: 'text', id: 'dialogApplyTime' + contId, style: { margin:"2px" }, className: 'inputime ' + inputClass }, dojo.create('div', { className:'empApply2VL' }, row));
	if(applyObj){
		inp.value = teasp.util.time.timeValue(applyObj.endTime, this.timeForm);
		if(teasp.constant.STATUS_FIX.contains(applyObj.status) || this.isReadOnly()){
			inp.readOnly = 'readOnly';
		}
		this.changeInputAreaView(inp, applyObj, fix);
	}else{
		var st = this.dayWrap.getStartTime(true, null, teasp.constant.C_REAL);
		if(st){
			inp.value = teasp.util.time.timeValue(st, this.timeForm);
		}
	}

	this.createNoteParts(key, tbody, contId, applyObj, teasp.message.getLabel('reason_label')); // 理由
	if((fix && applyObj && applyObj.treatDeduct) || this.pouch.isUseOwnReasonLateStart()){ // "自己都合による"チェックボックスを使用
		row  = dojo.create('div', { id: 'dialogApplyLateEscapeRow' + contId, className:'empApply2Div' }, tbody);
		dojo.create('div', { className: 'empApply2CL' }, row);
		if(fix && applyObj){
			dojo.create('div', {
				innerHTML:(applyObj.ownReason ? '自己都合による' : '会社都合による'),
				style:'border:1px solid #808080;padding:2px 8px;'
			}, dojo.create('div', { className:'empApply2VL', style:'padding:0px 2px;' }, row));
		}else{
			inp = dojo.create('select', {
				id:'dialogApplyLateEscape' + contId
			}, dojo.create('div', { className:'empApply2VL', style:'padding:0px 2px;' }, row));
			dojo.create('option', { innerHTML:'自己都合による', value:'1' }, inp);
			dojo.create('option', { innerHTML:'会社都合による', value:'0' }, inp);
			inp.value = (applyObj ? (applyObj.ownReason ? '1' : '0') : '1');
		}
	}

	this.createApplySetParts (key, tbody, contId, applyObj); // 承認者設定
	this.createApplyTimeParts(key, tbody, contId, applyObj); // 申請日時
	this.createStatusParts   (key, tbody, contId, applyObj); // 状況
	this.createErrorParts    (key, tbody, contId); // エラーメッセージ出力エリア

	if(btnbox){
		dojo.place(btnbox, tbody);
	}

	// 時刻入力時の補正
	dojo.query('.inputime', dojo.byId('dialogApplyTimeRow' + contId)).forEach(function(elem) {
		this.eventHandles.push(dojo.connect(elem, 'blur'      , this, teasp.util.time.onblurTime));
		this.eventHandles.push(dojo.connect(elem, 'onkeypress', this, teasp.util.time.onkeypressTime));
	}, this);

	this.drawLast(applyObj, node);

	// 申請ボタンが押された時の処理
	var btnOk = dojo.byId('empApplyDone' + contId);
	if(btnOk){
		this.eventHandles.push(dojo.connect(btnOk, 'onclick', this, function(e){
			var t = teasp.util.time.clock2minutes(dojo.byId('dialogApplyTime' + contId).value);
			if(t === undefined){
				teasp.dialog.EmpApply.showError(contId, teasp.message.getLabel('tm10003350')); // 時刻を入力してください
				return;
			}
			var st = this.dayWrap.getBorderTime().st;
			if(st < 0 || st >= t){
				teasp.dialog.EmpApply.showError(contId, teasp.message.getLabel('tm10003360', teasp.util.time.timeValue(st, this.timeForm))); // 入力された時刻は遅刻に該当しません（定時：{0}）
				return;
			}
			var chk = dojo.byId('dialogApplyLateEscape' + contId);
			var req = {
				empId            : this.pouch.getEmpId(),
				month            : this.pouch.getYearMonth(),
				startDate        : this.pouch.getStartDate(),
				lastModifiedDate : this.pouch.getLastModifiedDate(),
				date             : this.args.date,
				apply            : {
					id           : (applyObj ? applyObj.id : null),
					applyType    : teasp.constant.APPLY_TYPE_LATESTART,
					patternId    : null,
					holidayId    : null,
					status       : null,
					startDate    : this.args.date,
					endDate      : this.args.date,
					exchangeDate : null,
					startTime    : st,
					endTime      : t,
					note         : (dojo.byId('dialogApplyNote' + contId).value || null),
					contact      : null,
					ownReason    : (chk && chk.value == '1' ? true : false),
					treatDeduct  : this.pouch.getTreatLateStart()
				}
			};
			if(this.pouch.isRequireNote(teasp.constant.APPLY_KEY_LATESTART)
			&& !req.apply.note){
				teasp.dialog.EmpApply.showError(contId, teasp.message.getLabel('tm10003690')); // 理由を入力してください
				return;
			}
			if(this.dayWrap.getInputLimit().flag){ // 直行・直帰申請あり
				// サーバへ送信
				this.requestDirectApply(contId, req, true);
			}else{
				// サーバへ送信
				this.requestSend(contId, req);
			}
		}));
	}
};

